    package theater.seating;

    public enum SeatType {
        OT,
        IT,
        MT
    }
